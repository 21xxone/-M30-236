from matplotlib import  pyplot as plt
import numpy as np
A = [0, 35.2] # задаем координаты точек
B = [28, 0]
C = [19, 19]
D = [17, 17]
plt.grid() # создаем сетку
plt.fill_between([13.827,19],[17,12.886], color='#b3ccff') # заливаем область наших ограничений
plt.fill_between([0,13.827],[17,17], color='#b3ccff')
plt.xlim(0,50) # лимит по осям x,y
plt.ylim(0,50)
plt.title('Графический способ решения ЗЛП') # Название
plt.xlabel('arg x') # подпись осей
plt.ylabel('arg y')
plt.plot(A,B, lw = 2, color='red') # создание линий
plt.plot(C, [0,30], lw = 2, color='brown')
plt.plot([0, 30], D, lw = 2, color= 'green')
plt.arrow(0,0,3,5, width = 0.5, head_length = 4, head_width = 2) # создание вектора ( стрелки )
plt.text(5, 25, 'y <= -0.8x + 28.2') # подпись графиков
plt.text(20, 5, 'x <= 19')
plt.text(3, 18, 'y <= 17')
plt.text(5, 4, 'Вектор')
plt.show() # показать график
plt.savefig('C:\\график.png', dpi = 300) # сохранить график
#pease